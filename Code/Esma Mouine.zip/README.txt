R�partition des t�ches: �quipe form�e d'une seule personne
Difficult�: Compr�hension du r�le de chaque m�thode de la classe de classification
Description des classes:

Classe Knn: impl�mente la m�thode des k plus proches voisins pour pr�dire la classe des donn�es

Classe Bay�sien Na�f: utilise la classification na�ve bay�sienne pour pr�dire la classe des donn�es

Les deux classes affiche la matrice de confusion, l'exactitude, la pr�cision et le rappel
lors de l'appelle de la m�thode test

Classe load_datasets: Load les datasets bezdekIris, house-votes et monks
pour �tre utilis� pour la classification 
